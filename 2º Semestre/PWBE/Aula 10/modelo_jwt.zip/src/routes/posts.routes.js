const postsController = require("../controllers/posts.controller");

const express = require('express');

const postsRoutes = express.Router();

postsRoutes.get('/posts', postsController.createpost);

module.exports = postsRoutes;