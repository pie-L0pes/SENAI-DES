const connection = require("mysql2/promise");

const pool = connection.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "",
});

module.exports = pool;